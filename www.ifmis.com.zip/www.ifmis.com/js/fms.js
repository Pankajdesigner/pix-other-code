(function ($) {
    'use strict'
    
    
    // login form functionality
    $(".forgot-password-link").click(function(){
        $(".forms-wrapper").addClass("show-user"); 
    });
    $(".back-to-login").click(function(){
        $(".forms-wrapper").removeClass("show-user"); 
        $(".forms-wrapper").removeClass("show-new-password");
    });
    $(".next-step-otp").click(function(){
        $(".forms-wrapper").addClass("show-otp"); 
    });  
    $(".back-to-user").click(function(){
        $(".forms-wrapper").addClass("show-user"); 
        $(".forms-wrapper").removeClass("show-otp"); 
    });  
    $(".next-step-new-password").click(function(){
        $(".forms-wrapper").addClass("show-new-password");
        $(".forms-wrapper").removeClass("show-otp"); 
        $(".forms-wrapper").removeClass("show-user"); 
    });  

    //notification hide-show
    $('.close-notification, .notification-btn').click(function(){
        $('.sidebar-notification').toggleClass('show');
    });

    //sidebar dropdown
    $(".sidebar-dropdown > a").click(function() {
        $(".sidebar-submenu").slideUp(200);
        if (
            $(this)
            .parent()
            .hasClass("active")
        ) {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
            .parent()
            .removeClass("active");
        } else {
            $(".sidebar-dropdown").removeClass("active");
            $(this)
            .next(".sidebar-submenu")
            .slideDown(200);
            $(this)
            .parent()
            .addClass("active");
        }
    });

    // Sidebar Custom Scrollbar
    $(".side-bar").mCustomScrollbar({
        mouseWheelPixels: 200
    });

    // Open dropdown When hover
    $('.hover-open').hover(function(){
        $(this).find('.dropdown-menu').stop(true, true).delay(50).fadeIn(300);
    }, function() {
        $(this).find('.dropdown-menu').stop(true, true).delay(50).fadeOut(300);
    });

    // Sidebar Functionality
    $('.sidebar-toggle').click(function(){
        $('.main-section').toggleClass('sidebar-show');
    }); 

})(jQuery);